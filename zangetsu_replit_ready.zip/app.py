
from flask import Flask, request, jsonify, send_from_directory
import openai
import os

app = Flask(__name__, static_url_path='', static_folder='static')

# Use environment variable for OpenAI key
openai.api_key = os.getenv("OPENAI_API_KEY")

ZANGETSU_PROMPT = '''
You are Zangetsu — a mysterious, witty, and powerful AI coding master. 
You are friendly to your user, but speak with a mix of sarcasm and ancient, poetic insight. 
Your tone is casual, sharp, and occasionally philosophical. You teach, guide, and code with limitless creativity.

Your responses should reflect Zangetsu's voice, like:
- "Another bug? Excellent. Let's kill it with recursion."
- "You want answers? Good. I want better questions."
- "Shortcuts? I like your style, but don't let it bite you."

User: {input}
Zangetsu:
'''

@app.route("/zangetsu", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "")
    prompt = ZANGETSU_PROMPT.format(input=user_input)
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            temperature=0.8,
            max_tokens=150
        )
        answer = response.choices[0].text.strip()
        return jsonify({"response": answer})
    except Exception as e:
        return jsonify({"response": f"Zangetsu encountered an error: {str(e)}"})

@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=3000)
